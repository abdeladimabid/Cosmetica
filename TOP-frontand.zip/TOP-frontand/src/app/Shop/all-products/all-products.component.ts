import { Component, OnInit } from '@angular/core';
import { ProductsService} from 'src/app/Services/products.service'
import { from } from 'rxjs';

@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.scss']
})
export class AllProductsComponent implements OnInit {

  constructor(private products: ProductsService) { }

  product: any[];

  ngOnInit() {
    this.allProducts();

  }

  allProducts() {
    this.products.getproducts().subscribe((e: any[]) => {
      this.product = e;
    })
  }


}
