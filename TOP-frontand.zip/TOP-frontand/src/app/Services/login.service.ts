import { Observable, config, BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { User } from '@app/_models';

@Injectable({
  providedIn: 'root'
})
export class LoginService {





  constructor(private http: HttpClient) { }

  login(data) {

    return this.http.post<any>("http://localhost:8020/COSMETICA/authenticate", data);

  }


  register(data) {
    return this.http.post<any>('http://localhost:8020/COSMETICA/signup/client/add', data)
  }

}
