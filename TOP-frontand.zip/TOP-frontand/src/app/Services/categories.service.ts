import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { config } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoriesService {

  constructor(private http: HttpClient) { }

  getcategories() {
    return this.http.get('http://localhost:8020/COSMETICA/category/all');
  }

  getSubcategories1() {
    return this.http.get('http://localhost:8020/COSMETICA/category/children/1');
  }

  getSubcategories2() {
    return this.http.get('http://localhost:8020/COSMETICA/category/children/2');
  }
  getSubcategories3() {
    return this.http.get('http://localhost:8020/COSMETICA/category/children/3');
  }
  getSubcategories4() {
    return this.http.get('http://localhost:8020/COSMETICA/category/children/4');
  }
}
