import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllProductsComponent } from './Shop/all-products/all-products.component';
import { HomeComponent } from './HOME/home/home.component';
import { ContactComponent } from './contact/contact.component';

import { from } from 'rxjs';
import { LoginComponent } from './login/login/login.component';
import { RegisterComponent } from './login/register/register.component';

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "AllProductsComponent", component: AllProductsComponent },
  { path: "ContactComponent", component: ContactComponent },
  { path: "Login", component: LoginComponent },
  { path: "Login/Register", component: RegisterComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
