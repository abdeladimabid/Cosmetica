import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './HOME/navbar/navbar.component';
import { SliderComponent } from './HOME/slider/slider.component';
import { CategoriesComponent } from './HOME/categories/categories.component';
import { ProductsComponent } from './HOME/products/products.component';
import { AllProductsComponent } from './Shop/all-products/all-products.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { RegisterComponent } from './login/register/register.component';
import { FooterComponent } from './HOME/footer/footer.component';
import { HomeComponent } from './HOME/home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { BrandsComponent } from './HOME/brands/brands.component';
import { LoginComponent } from './login/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SliderComponent,
    CategoriesComponent,
    ProductsComponent,
    AllProductsComponent,
    AboutComponent,
    ContactComponent,
    RegisterComponent,
    FooterComponent,
    HomeComponent,
    BrandsComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
