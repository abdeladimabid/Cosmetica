import { Component, OnInit } from '@angular/core';
import { LoginService } from './../../Services/login.service';
import { Router } from '@angular/router'
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  registerForm = new FormGroup({
    'username': new FormControl(null),
    'email': new FormControl(null),
    'password': new FormControl(null)
  });

  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit() {
  }

  createAccount() {
    this.loginService.register(this.registerForm.value)
        .subscribe(res => this.router.navigate(['/']));
  }

}
