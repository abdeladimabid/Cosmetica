import { LoginService } from './../../Services/login.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { FormGroup, FormControl } from '@angular/forms';
import { TokenService } from 'src/app/Services/token.service';
import { AuthService } from 'src/app/Services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm = new FormGroup({
    'username': new FormControl(),
    'password': new FormControl(),
  })

  loginUserData = {}

  constructor(private login: LoginService, private Token: TokenService, private router: Router,private Auth: AuthService) { }

  ngOnInit() {
  }



  loginNow() {
    this.login.login(this.loginForm.value)
    .subscribe(res => this.handleResponse(res));
  }

  handleResponse(data) {

    this.Token.handle(data.token);
    this.Auth.changeAuthStatus(true);
    this.router.navigateByUrl('/');
  }
}
