import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/Services/products.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  constructor(private products: ProductsService) { }

  product: any[];

  ngOnInit() {
    this.allProducts();

  }

  allProducts() {
    this.products.getproducts().subscribe((e: any[]) => {
      this.product = e;
    })
  }
}
