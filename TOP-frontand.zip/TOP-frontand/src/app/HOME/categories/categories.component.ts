import { Component, OnInit } from '@angular/core';
import { CategoriesService } from 'src/app/Services/categories.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {

  constructor( private categories: CategoriesService ) { }

  categ : any[];
  SubCategories: any[];
  SubCategories1: any[];
  SubCategories2: any[];
  SubCategories3: any[];

  Index: number;
  cat = true;

  ngOnInit() {
    this.getallcategories();
    this.getallSubcat();
    this.getallSubcat1();
    this.getallSubcat2();
    this.getallSubcat3();
  }


  getallcategories() {
    this.categories.getcategories().subscribe((data: any[]) => {
      this.categ = data;
    })

  }

  getallSubcat() {
    this.categories.getSubcategories1().subscribe((data: any[]) => {

      this.SubCategories = data;


    })
  }


  getallSubcat1() {
    this.categories.getSubcategories2().subscribe((data: any[]) => {

      this.SubCategories1 = data;


    })
  }
  getallSubcat2() {
    this.categories.getSubcategories3().subscribe((data: any[]) => {

      this.SubCategories2 = data;


    })
  }

  getallSubcat3() {
    this.categories.getSubcategories4().subscribe((data: any[]) => {

      this.SubCategories3 = data;


    })
  }


  Incr(j) {

    this.Index = j;
    this.cat = false;

  }



}
